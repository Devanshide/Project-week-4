import React, { useState } from "react";
import "./App.css";
import AdminPanel from "./adminpanel";

function App() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    fromDate: "",
    toDate: "",
    reason: "",
  });

  const [view, setView] = useState("form"); // "form" or "admin"

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:3000/api/leave/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (res.ok) {
        alert("Leave request submitted successfully!");
        setFormData({
          name: "",
          email: "",
          fromDate: "",
          toDate: "",
          reason: "",
        });
      } else {
        alert("Error: " + data.error);
      }
    } catch (err) {
      alert("Error connecting to backend.");
    }
  };

  return (
    <div className="App">
      <div style={{ marginBottom: "20px" }}>
        <button onClick={() => setView("form")}>Leave Form</button>
        <button onClick={() => setView("admin")}>Admin Panel</button>
      </div>

      {view === "form" ? (
        <>
          <h2>Leave Application Form</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Your name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Your email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <input
              type="date"
              name="fromDate"
              value={formData.fromDate}
              onChange={handleChange}
              required
            />
            <input
              type="date"
              name="toDate"
              value={formData.toDate}
              onChange={handleChange}
              required
            />
            <textarea
              name="reason"
              placeholder="Reason for leave"
              value={formData.reason}
              onChange={handleChange}
              required
            />
            <button type="submit">Submit</button>
          </form>
        </>
      ) : (
        <AdminPanel />
      )}
    </div>
  );
}

export default App;
