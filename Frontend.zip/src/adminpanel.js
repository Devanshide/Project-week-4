import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminPanel = () => {
  const [leaves, setLeaves] = useState([]);

  useEffect(() => {
    fetchLeaves();
  }, []);

  const fetchLeaves = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/leave/all");
      setLeaves(res.data);
    } catch (err) {
      console.error("Error fetching leaves", err);
    }
  };

  const updateStatus = async (id, status) => {
    try {
      await axios.put(`http://localhost:3000/api/leave/update/${id}`, { status });
      fetchLeaves(); // Refresh
    } catch (err) {
      console.error("Error updating status", err);
    }
  };

  return (
    <div style={{ padding: "30px", fontFamily: "Arial, sans-serif" }}>
      <h2 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>
        🛠️ Admin Panel - Leave Requests
      </h2>

      {leaves.length === 0 ? (
        <p style={{ fontStyle: "italic", color: "gray" }}>No leave requests found.</p>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", minWidth: "800px" }}>
            <thead>
              <tr style={{ backgroundColor: "#1f2937", color: "white" }}>
                <th style={thStyle}>Name</th>
                <th style={thStyle}>Email</th>
                <th style={thStyle}>Reason</th>
                <th style={thStyle}>From</th>
                <th style={thStyle}>To</th>
                <th style={thStyle}>Status</th>
                <th style={thStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {leaves.map((leave) => (
                <tr key={leave._id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                  <td style={tdStyle}>{leave.name}</td>
                  <td style={tdStyle}>{leave.email}</td>
                  <td style={tdStyle}>{leave.reason}</td>
                  <td style={tdStyle}>{leave.fromDate}</td>
                  <td style={tdStyle}>{leave.toDate}</td>
                  <td style={{ ...tdStyle, fontWeight: "bold", color: getStatusColor(leave.status) }}>
                    {leave.status}
                  </td>
                  <td style={tdStyle}>
                    <button
                      onClick={() => updateStatus(leave._id, "Approved")}
                      style={btnGreen}
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => updateStatus(leave._id, "Rejected")}
                      style={btnRed}
                    >
                      Reject
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ✨ Styling Helpers
const thStyle = {
  padding: "12px",
  textAlign: "left",
  fontWeight: "bold",
  fontSize: "14px",
};

const tdStyle = {
  padding: "10px",
  fontSize: "14px",
  verticalAlign: "top",
};

const btnGreen = {
  backgroundColor: "#10b981",
  color: "white",
  border: "none",
  padding: "8px 12px",
  borderRadius: "5px",
  cursor: "pointer",
  marginRight: "8px",
};

const btnRed = {
  backgroundColor: "#ef4444",
  color: "white",
  border: "none",
  padding: "8px 12px",
  borderRadius: "5px",
  cursor: "pointer",
};

const getStatusColor = (status) => {
  switch (status) {
    case "Approved":
      return "#10b981";
    case "Rejected":
      return "#ef4444";
    default:
      return "#6b7280"; // gray
  }
};

export default AdminPanel;
