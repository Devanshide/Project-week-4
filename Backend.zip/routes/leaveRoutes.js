const express = require("express");
const router = express.Router();
const Leave = require("../models/Leave");

// ✅ POST: Apply for Leave
router.post("/apply", async (req, res) => {
  try {
    const leave = new Leave(req.body);
    await leave.save();
    res.status(201).send({ message: "Leave request submitted!" });
  } catch (err) {
    res.status(400).send({ error: "Failed to submit leave", details: err.message });
  }
});

// ✅ GET: All Leave Requests
router.get("/all", async (req, res) => {
  try {
    const leaves = await Leave.find();
    res.send(leaves);
  } catch (err) {
    res.status(500).send({ error: "Failed to fetch leaves", details: err.message });
  }
});

// ✅ PUT: Update Leave Status
router.put("/update/:id", async (req, res) => {
  try {
    const { status } = req.body;
    await Leave.findByIdAndUpdate(req.params.id, { status });
    res.send({ message: `Status updated to ${status}` });
  } catch (err) {
    res.status(400).send({ error: "Status update failed", details: err.message });
  }
});

// ✅ PATCH: Approve
router.patch("/approve/:id", async (req, res) => {
  try {
    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status: "Approved" },
      { new: true }
    );
    if (!leave) return res.status(404).send({ message: "Leave not found" });
    res.send({ message: "Leave approved", leave });
  } catch (err) {
    res.status(500).send({ error: "Approval failed", details: err.message });
  }
});

// ✅ PATCH: Reject
router.patch("/reject/:id", async (req, res) => {
  try {
    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status: "Rejected" },
      { new: true }
    );
    if (!leave) return res.status(404).send({ message: "Leave not found" });
    res.send({ message: "Leave rejected", leave });
  } catch (err) {
    res.status(500).send({ error: "Rejection failed", details: err.message });
  }
});

module.exports = router;
